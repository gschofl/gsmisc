Here you can store any output that you produce that is intended for downstream processing outside of R.
